# Instalación de Skills para Mentelyx (Windows / PowerShell)

Las Skills en `.agents/skills/` funcionan **dentro del repositorio donde están colocadas**. Las que están en `E:\LORIX\.agents\skills` son específicas de LORIX. Para instalaciones de usuario compartidas, usa `$HOME\.agents\skills`.

## 1. Comprobar Skills ya instaladas

En PowerShell:

```powershell
Get-ChildItem 'E:\LORIX\.agents\skills' -Directory -ErrorAction SilentlyContinue | Select-Object Name
Get-ChildItem "$HOME\.agents\skills" -Directory -ErrorAction SilentlyContinue | Select-Object Name
```

Para comprobar las del proyecto de Mentelyx, abre su carpeta raíz en VS Code y en la terminal ejecuta:

```powershell
Get-Location
Get-ChildItem '.\.agents\skills' -Directory -ErrorAction SilentlyContinue | Select-Object Name
```

## 2. Instalar este paquete sin sobreescribir otros archivos

Abre la carpeta **raíz de Mentelyx** en VS Code. Extrae el ZIP primero en una carpeta temporal. Copia la carpeta `.agents` del ZIP hacia la raíz del proyecto (fusionando carpetas, no sustituyéndolas). Si ya existe una Skill con el mismo nombre, compara su contenido antes de reemplazarla.

Como alternativa, desde PowerShell en la raíz de Mentelyx, reemplaza la ruta del ZIP:

```powershell
$zip = 'C:\ruta\descargas\mentelyx-skills.zip'
$tmp = Join-Path $env:TEMP 'mentelyx-skills-nuevas'
New-Item -ItemType Directory -Force -Path $tmp | Out-Null
Expand-Archive -Path $zip -DestinationPath $tmp -Force
foreach ($name in @('mentelyx-docs','mentelyx-build','mentelyx-check')) {
  $dest = Join-Path (Get-Location) ".agents\skills\$name"
  if (Test-Path $dest) { Write-Warning "Ya existe $dest. Revisar antes de reemplazar."; continue }
  New-Item -ItemType Directory -Force -Path (Split-Path $dest) | Out-Null
  Copy-Item -Recurse -Path (Join-Path $tmp ".agents\skills\$name") -Destination $dest
}
```

No copies `AGENTS-mentelyx.example.md` sobre un `AGENTS.md` que ya exista. Si quieres sus reglas, **fusiona** solo las líneas aplicables con el `AGENTS.md` existente.

## 3. Invocación en Codex

Inicia Codex desde la raíz del proyecto. Puedes activar explícitamente una Skill usando:

```text
$mentelyx-docs: En el documento Diseño interno de módulos, completa la sección 6 con código de referencia para M1–M7, conservando M5 e ilustrando M6 con mayor profundidad. No toques otros documentos.
```

```text
$mentelyx-check: Revisa exclusivamente el diff del diseño interno; reporta pérdidas, incoherencias y secciones pendientes. No edites.
```

```text
$mentelyx-build: Implementa solo el primer flujo educativo acordado, con pruebas focalizadas; respeta el contrato entre M1, M2, M3 y M6.
```

Si no detecta los archivos nuevos, termina la sesión y vuelve a iniciar `codex` en la carpeta raíz. Comprueba la lista de skills que muestre tu versión del cliente.

## 4. Uso prudente de límites

En una sesión activa de Codex escribe `/status` para revisar la asignación disponible. Las Skills **no recargan créditos**: reducen instrucciones repetidas, pero las tareas grandes y los contextos extensos todavía consumen uso. Pide una tarea por turno y evita análisis globales sin necesidad.
