# Mentelyx — instrucciones breves para Codex

- Este repositorio desarrolla Mentelyx, plataforma de aprendizaje virtual con Tutor IA y docentes humanos.
- Respeta la documentación vigente como fuente de verdad; si hay contradicciones, informa, no inventes.
- Arquitectura prevista: monolito modular; Clean Architecture dentro de cada módulo. Revisa los ADR cuando la tarea implique decisiones técnicas.
- M1 usuarios; M2 cursos; M3 evaluación; M4 docentes; M5 pagos; M6 tutor IA y RAG; M7 publicidad.
- M6 es el componente funcional diferenciador; M5 es soporte comercial. Mantén límites y contratos públicos.
- Si editas documentación, conserva apartados, ejemplos, diagramas, identificadores y material válido; realiza cambios mínimos.
- Si implementas código, haz una funcionalidad verificable por tarea y ejecuta pruebas afectadas.
- No publiques claves, no despliegues ni hagas cambios destructivos sin pedido explícito.
- Usa `$mentelyx-docs`, `$mentelyx-build` o `$mentelyx-check` según corresponda; no leas las tres Skills para cada tarea.
